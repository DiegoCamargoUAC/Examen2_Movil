package com.example.examen2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.database.Cursor;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CRUDRecetas CRUD = new CRUDRecetas(this);
        ArrayList<String> listaRecetitas = new ArrayList<String>();

        ListView listaRecetas = findViewById(R.id.listaRecetas);
        Cursor informacion = CRUD.mostrarRecetas();
        while (informacion.moveToNext()) {
            String titulo = informacion.getString(1);
            listaRecetitas.add(titulo);
        }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listaRecetitas);
        listaRecetas.setAdapter(adaptador);

        Button btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editTitulo = findViewById(R.id.editTitulo);
                EditText editDescripcion = findViewById(R.id.editDescripcion);
                String titulo = editTitulo.getText().toString();
                String descripcion = editDescripcion.getText().toString();

                if (!titulo.isEmpty() || !descripcion.isEmpty()) {
                    CRUD.insertarReceta(titulo, descripcion);
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                } else {
                }
            }
        });

        Button btnEliminar = findViewById(R.id.btnBorrar);
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editId = findViewById(R.id.editId);
                String idString = editId.getText().toString();
                Integer id = Integer.parseInt(idString);
                CRUD.eliminarReceta(id);
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });

        Button btnEditar = findViewById(R.id.btnEditar);
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editId = findViewById(R.id.editId);
                EditText editTitulo = findViewById(R.id.editTitulo);
                EditText editDescripcion = findViewById(R.id.editDescripcion);
                String idString = editId.getText().toString();
                String titulo = editTitulo.getText().toString();
                String descripcion = editDescripcion.getText().toString();

                if (!idString.isEmpty() && !titulo.isEmpty() && !descripcion.isEmpty()) {
                    int id = Integer.parseInt(idString);
                    CRUD.actualizarReceta(id, titulo, descripcion);
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                } else {
                }
            }
        });
    }
}